
module.exports={
    "facebook_key"      :     "822854365468005", //Điền App ID của bạn vào đây
    "facebook_secret"   :     "63292624ded7aa4376c58464b7e9cafe", //Điền App Secret ở đây
    "callback_url"      :     "https://minhhieu45.site/auth/facebook/callback"
  }